#import "@@PROJECTNAME@@.h"

#define kPrefsPath @"/var/mobile/Library/Preferences/@@PACKAGENAME@@.plist"
#define kPrefsBlurKey @"blur"
#define kDefaultHeight 120
#define kExpandedHeight 200
#define kMargin 14

@interface @@PROJECTNAME@@ ()
@property (nonatomic) UIView *contentView;
@property (nonatomic) UILabel *label;
@property (nonatomic) BOOL expanded;
@end

@implementation @@PROJECTNAME@@

- (@@PROJECTNAME@@ *)initWithHostView:(UIView *)hostView
{
    if(self = [super initWithHostView:hostView]) {

        self.height = kDefaultHeight;
        _expanded = NO;

        _contentView = [[UIView alloc] initWithFrame:CGRectMake(kMargin, kMargin, self.frame.size.width - (kMargin*2), self.height - (kMargin*2))];
        _contentView.backgroundColor = [self lightWidgetColor];
        _contentView.layer.cornerRadius = 6;
        _contentView.layer.masksToBounds = YES;
        [self addSubview:_contentView];

        _label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, _contentView.frame.size.width, _contentView.frame.size.height)];
        _label.textColor = [UIColor whiteColor];
        _label.font = [UIFont systemFontOfSize:18];
        _label.textAlignment = NSTextAlignmentCenter;
        _label.text = @"@@PROJECTNAME@@";
        [_contentView addSubview:_label];

    }
    return self;
}

- (void)widgetWillAppear:(BOOL)animated {

    NSDictionary *prefs = [NSDictionary dictionaryWithContentsOfFile:kPrefsPath];
    BOOL blur = [prefs objectForKey:kPrefsBlurKey] == nil ? NO : [[prefs objectForKey:kPrefsBlurKey] boolValue];
    if(blur) { self.hostingAppEffect = WCEffectBlur; }
    else { self.hostingAppEffect = WCEffectDarken; }

}

- (void)widgetHoldAction { [self dismissWidgetCenter]; }

- (void)dealloc {

    [super dealloc];
    [_contentView release];
    [_label release];

}

#pragma mark Widget Expanding/Shrinking

- (BOOL)widgetCanExpandAndShrink { return YES; }

- (BOOL)widgetIsExpanded { return _expanded; }

- (void)widgetExpandAction {

    _expanded = YES;

    [self updateWidgetHeight:kExpandedHeight animated:YES withAnimations:^{
        _contentView.frame = CGRectMake(_contentView.frame.origin.x, _contentView.frame.origin.y, _contentView.frame.size.width, kExpandedHeight - (kMargin*2));
        _label.frame = CGRectMake(_label.frame.origin.x, _label.frame.origin.y, _label.frame.size.width, _contentView.frame.size.height);
    } completion:nil];

}

- (void)widgetShrinkAction {

    _expanded = NO;
    [self updateWidgetHeight:kDefaultHeight animated:YES withAnimations:^{
        _contentView.frame = CGRectMake(_contentView.frame.origin.x, _contentView.frame.origin.y, _contentView.frame.size.width, kDefaultHeight - (kMargin*2));
        _label.frame = CGRectMake(_label.frame.origin.x, _label.frame.origin.y, _label.frame.size.width, _contentView.frame.size.height);
    } completion:nil];

}

@end
