#import <libwcwidget/WCWidget.h>

@interface @@PROJECTNAME@@ : WCWidget

- (@@PROJECTNAME@@ *)initWithHostView:(UIView *)hostView;

@end